# NZXT-ESC — Documentation

This directory contains language-specific documentation files.

If you are not automatically redirected, select your preferred language:

- [🇬🇧 English](../README.md)
- [🇹🇷 Türkçe](README.tr.md)
- [🇩🇪 Deutsch](README.de.md)
- [🇪🇸 Español](README.es.md)
- [🇧🇷 Português-BR](README.pt-BR.md)
- [🇫🇷 Français](README.fr.md)
- [🇮🇹 Italiano](README.it.md)
- [🇯🇵 日本語](README.ja.md)

